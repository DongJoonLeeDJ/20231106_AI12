import pandas as pd

country = pd.read_csv("C:\\Users\\KB\\Desktop\\ISO국가코드.csv", encoding='cp949')
stat = pd.read_csv("C:\\Users\\KB\\Desktop\\김홍근프로\\Raw_DATA\\Statics.csv", encoding='cp949')


def Name_Find(line):
    long, lati, co = [], [], []

    co = country['2자리코드']
    iso = country['iso 숫자코드']
    name = country['영문명']

    for co_code, num, na in zip(co, iso, name):
        if line == co_code:
            iso_num = num
            name_en = na.capitalize()
            return [iso_num, name_en]

    return ['Unknown', 'Unknown']
country_name, code_num, en_na = [], [], []
for co in stat['Co_code']:

    country_name.append(Name_Find(co))

for i in range(len(country_name)):
   code_num.append(country_name[i][0])
   en_na.append(country_name[i][1])

stat['iso_num'] = code_num
stat['name'] = en_na

print(stat)

stat.to_csv("C:\\Users\\KB\\Desktop\\김홍근프로\\Raw_DATA\\Result.csv")