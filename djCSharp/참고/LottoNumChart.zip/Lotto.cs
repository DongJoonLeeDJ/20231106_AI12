﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LottoNumChart
{
    public class Lotto : IComparable<Lotto>
    {
        public string Num { get; set; }
        public int count { get; set; }

        public int CompareTo(Lotto other)
        {
            return other.count.CompareTo(count);
        }
    }
}
