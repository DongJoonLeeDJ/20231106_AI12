﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace LottoNumChart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Lotto[] lottonumcount = new Lotto[45];
            for (int i = 0; i < 45; i++)
            {
                lottonumcount[i] = new Lotto();
                lottonumcount[i].Num = i+1+"";
            }
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Add("drwNo", "회차");
            dataGridView1.Columns.Add("ltn1", "첫번째 번호");
            dataGridView1.Columns.Add("ltn2", "두번째 번호");
            dataGridView1.Columns.Add("ltn3", "세번째 번호");            
            dataGridView1.Columns.Add("ltn4", "네번째 번호");
            dataGridView1.Columns.Add("ltn5", "다섯번째 번호");
            dataGridView1.Columns.Add("ltn6", "여섯번째 번호");
            dataGridView1.Columns.Add("ltn_bns", "보너스 번호");
            string url = "https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=";
            int count = 1; //로또 1000회차부터 현재 회차까지 출력을 할 것
            while (true)
            {
                using (WebClient wc = new WebClient()) //using 끝나면 wc는 메모리 해제됨
                {
                    var json = wc.DownloadString(url + count);
                    count++;
                    var jArray = JObject.Parse(json); //using Newtonsoft.Json.Linq = json 라이브러리 깔아서 그렇다.
                    if (jArray["returnValue"].ToString() != "success") //=="fail"
                        break;
                    dataGridView1.Rows.Add(jArray["drwNo"].ToString(),jArray["drwtNo1"].ToString(), jArray["drwtNo2"].ToString(), jArray["drwtNo3"].ToString(), jArray["drwtNo4"].ToString(), jArray["drwtNo5"].ToString(), jArray["drwtNo6"].ToString(), jArray["bnusNo"].ToString());
                    lottonumcount[int.Parse(jArray["drwtNo1"].ToString()) - 1].count++;
                    lottonumcount[int.Parse(jArray["drwtNo2"].ToString()) - 1].count++;
                    lottonumcount[int.Parse(jArray["drwtNo3"].ToString()) - 1].count++;
                    lottonumcount[int.Parse(jArray["drwtNo4"].ToString()) - 1].count++;
                    lottonumcount[int.Parse(jArray["drwtNo5"].ToString()) - 1].count++;
                    lottonumcount[int.Parse(jArray["drwtNo6"].ToString()) - 1].count++;
                    lottonumcount[int.Parse(jArray["bnusNo"].ToString()) - 1].count++;
                }
            }

            //chart1.Series.Clear();

            //chart1.Series.Add("로또번호");
            //chart1.ChartAreas[0].AxisX.LabelStyle.Interval = 1; //x축 간격
            /*
             chartArea1.Area3DStyle.Enable3D = true;
            chartArea1.AxisX.IsMarginVisible = false;
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(13, 213);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(1685, 427);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
             */
            //chart1.Series[0].Points.Clear();
            //chart1.Series[0].IsValueShownAsLabel = true;
            //chart1.Series[0].IsVisibleInLegend = false;
            for (int i =1; i<=45; i++)
            {
                chart1.Series[0].Points.AddXY(i, lottonumcount[i-1].count);
                //chart1.Series.Add("로또번호"+(i-1));
                //chart1.Series[i - 1].IsVisibleInLegend = false;
                //chart1.Series[i-1].IsValueShownAsLabel = true;
            }
            
            label1.Text = "가장 많이 나온 값(빈도순으로 총 7개의 값 출력) : ";
            Array.Sort(lottonumcount);
            label1.Text += lottonumcount[0].Num + " ";
            label1.Text += lottonumcount[1].Num + " ";
            label1.Text += lottonumcount[2].Num + " ";
            label1.Text += lottonumcount[3].Num + " ";
            label1.Text += lottonumcount[4].Num + " ";
            label1.Text += lottonumcount[5].Num + " ";
            label1.Text += lottonumcount[6].Num + " ";

            
        }
    }
}
